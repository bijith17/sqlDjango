from django.db import models

# Create your models here.
class LoginData(models.Model):
    username=models.TextField()
    name=models.TextField()
    password=models.TextField()